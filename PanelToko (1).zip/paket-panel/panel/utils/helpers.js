// utils/helpers.js
const crypto = require('crypto');

function formatRupiah(num) {
  return 'Rp' + Number(num).toLocaleString('id-ID');
}

// ID Transaksi format WX[nomor acak], contoh: WX583920
function generateTransactionId(digits = 6) {
  const min = Math.pow(10, digits - 1);
  const max = Math.pow(10, digits) - 1;
  return 'WX' + String(crypto.randomInt(min, max + 1));
}

// Validasi input jumlah pembelian: harus bilangan bulat positif (bukan huruf/minus/desimal)
function parsePositiveInt(text) {
  if (typeof text !== 'string') return null;
  const trimmed = text.trim();
  if (!/^[0-9]+$/.test(trimmed)) return null; // tolak huruf, minus, desimal, spasi di tengah
  const n = parseInt(trimmed, 10);
  if (!Number.isInteger(n) || n <= 0) return null;
  return n;
}

// Batasi teks pesan channel Discord (nama channel maks 100 char, huruf kecil & strip)
function toChannelSafeName(name) {
  return name
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-]/g, '')
    .slice(0, 90);
}

// Parse daftar role ID admin yang disimpan sebagai string dipisah koma (mendukung multi-role)
function parseRoleIds(str) {
  if (!str) return [];
  return str.split(',').map((s) => s.trim()).filter(Boolean);
}

module.exports = { formatRupiah, generateTransactionId, parsePositiveInt, toChannelSafeName, parseRoleIds };
