// utils/time.js
// Semua tanggal/waktu di bot WAJIB memakai zona WIB (Asia/Jakarta), format DD-MM-YYYY HH:mm

function formatWIB(date = new Date()) {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Jakarta',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).formatToParts(date);

  const map = {};
  for (const p of parts) map[p.type] = p.value;
  return `${map.day}-${map.month}-${map.year} ${map.hour}:${map.minute}`;
}

module.exports = { formatWIB };
