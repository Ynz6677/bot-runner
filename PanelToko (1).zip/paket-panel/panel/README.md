# Panel Toko — kontrol & pemantauan untuk bot Discord kamu

Ini **bukan toko kedua**. Panel ini tidak punya sistem order, produk, atau pembeli sendiri. Ia membaca langsung database yang dipakai bot Discord kamu, dan hanya bisa melakukan tiga hal:

1. **Buka / tutup toko** — menulis ke kolom `store_status` yang sudah ada, sama seperti tombol di `/admin_panel`.
2. **Restock** — menambah stok / data akun, sama seperti tombol Restock & Upload Akun.
3. **Kirim pengumuman** — menitipkan pesan yang lalu dikirim BOT sebagai embed ke Channel Info Toko.

Semua halaman lain (Order, Pembukuan, Vouch, Role Reward) **murni menampilkan**, tidak ada tombol ubah.

## Kenapa harus di HP/VPS yang sama dengan bot, bukan Vercel

Panel ini membaca file SQLite bot secara langsung — itu pilihan yang paling akurat dan real-time, sesuai yang kamu minta. File itu ada di penyimpanan lokal, jadi panel **wajib jalan di perangkat/server yang sama dengan bot** (Termux di HP yang sama, atau VPS yang sama). Vercel tidak bisa dipakai untuk mode ini karena serverless tidak punya akses ke file lokal.

Untuk tetap bisa diakses dari luar (HP lain, laptop, dari mana saja), pakai **Cloudflare Tunnel** — gratis, tanpa buka port:

```bash
pkg install -y cloudflared   # di Termux
cloudflared tunnel --url http://localhost:4000
```

Kamu akan dapat URL publik (`https://acak.trycloudflare.com`) yang meneruskan ke panel di HP kamu. Untuk URL tetap, buat Cloudflare Tunnel bernama lewat akun Cloudflare (gratis, sedikit lebih ribet — beri tahu saya kalau mau dipandu).

## Instalasi

```bash
cd panel
npm install
cp .env.example .env
nano .env
```

Isi minimal:

```
DB_PATH=/lokasi/persis/storage-database   # sama dengan DB_PATH milik bot
ADMIN_USERNAME=admin
ADMIN_PASSWORD=ganti-ini
SESSION_SECRET=string-acak-panjang
```

Kalau bot kamu tidak override `DB_PATH`, lokasi bawaannya di Termux adalah `~/storage/shared/storage-database` — panel akan menemukannya otomatis kalau `DB_PATH` dikosongkan.

Jalankan:

```bash
npm start
```

Buka `http://localhost:4000`, masuk pakai `ADMIN_USERNAME`/`ADMIN_PASSWORD` dari `.env`.

## Mengaktifkan fitur Pengumuman (opsional)

Restock dan buka/tutup toko langsung jalan tanpa patch apa pun ke bot, karena keduanya cuma menulis ke kolom yang sudah ada. **Kirim pengumuman** butuh bot yang aktif mengirim pesan ke Discord, jadi perlu satu patch kecil:

1. Salin `handlers/webPanel.js` (di paket ini, folder `DISCB/handlers/webPanel.js`) ke folder `handlers/` bot kamu.
2. Buka `database.js` bot kamu, tambahkan blok yang ditandai `JEMBATAN PANEL WEB` di bagian bawah file (sebelum `module.exports`), dan tiga nama fungsi baru (`takeBroadcastQueue`, `markBroadcastDone`, `writePanelHeartbeat`) di `module.exports`. Semua baris lain di `database.js` **tidak berubah sama sekali**.
3. Buka `events/ready.js` bot kamu, tambahkan satu baris `const webPanel = require('../handlers/webPanel');` di atas, dan satu baris `webPanel.start(client);` di dalam `execute()`.
4. Restart bot.

Diff lengkapnya kecil sekali — bisa dicek dengan `diff` terhadap bot aslimu. Tidak ada perintah, command, atau alur order yang diubah.

Kalau kamu tidak mau menyentuh bot sama sekali, biarkan saja fitur Pengumuman tidak aktif — sisanya (dashboard, restock, buka/tutup toko, semua laporan) tetap berfungsi penuh tanpa patch itu.

## Yang TIDAK ada di panel ini (sengaja)

- Tidak ada akun pembeli, tidak ada halaman belanja, tidak ada checkout.
- Tidak ada konfirmasi/pembatalan order dari web — itu tetap lewat Discord supaya satu sumber kebenaran.
- Tidak ada perubahan skema pada tabel `products`, `orders`, `vouches`, `role_rewards`, `transaksi_ledger` — panel hanya membaca tabel-tabel itu.
- Tidak ada duplikasi logika bisnis bot di sisi web.

## Struktur berkas

```
panel/
├── server.js         # entry point
├── db.js             # baca/tulis LANGSUNG ke database bot (lihat komentar di dalamnya)
├── middleware/auth.js # login admin tunggal dari .env
├── routes/panel.js    # semua rute
├── views/              # halaman EJS
└── public/css/style.css

DISCB/handlers/webPanel.js   # (opsional) patch kecil untuk fitur pengumuman
```
