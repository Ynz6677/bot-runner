// routes/panel.js — satu-satunya berkas rute. Panel ini sengaja kecil:
// beberapa halaman pantau (read-only) + tiga aksi yang diizinkan
// (buka/tutup toko, restock, kirim pengumuman).

const express = require('express');
const db = require('../db');
const { requireLogin } = require('../middleware/auth');
const { parsePositiveInt } = require('../utils/helpers');

const router = express.Router();
router.use(requireLogin);

const kembali = (res, url, pesan) =>
  res.redirect(`${url}${url.includes('?') ? '&' : '?'}pesan=${encodeURIComponent(pesan)}`);

// ---------- DASHBOARD ----------
router.get('/', (req, res, next) => {
  try {
    const cfg = db.getConfig();
    const produk = db.listProducts();
    res.render('dashboard', {
      title: 'Dashboard',
      cfg,
      tokoBuka: cfg.store_status === 'OPEN',
      pending: db.getPendingOrders(),
      terakhir: db.listOrders().filter((o) => o.status !== 'PENDING').slice(0, 10),
      pembukuan: db.getPembukuan(),
      stokTipis: produk.filter((p) => p.stock <= 2).slice(0, 8),
      botStatus: db.getBotStatus(),
      pesan: req.query.pesan || null,
    });
  } catch (err) { next(err); }
});

router.post('/toko/status', (req, res, next) => {
  try {
    const baru = db.toggleStoreStatus();
    kembali(res, '/', baru === 'OPEN' ? 'Toko dibuka.' : 'Toko ditutup.');
  } catch (err) { next(err); }
});

// ---------- PRODUK / RESTOCK ----------
router.get('/produk', (req, res, next) => {
  try {
    const produk = db.listProducts();
    const stokAkun = {};
    produk.filter((p) => p.type === 'akun').forEach((p) => { stokAkun[p.id] = db.countAccountLines(p.id); });
    res.render('produk', { title: 'Produk & Stok', produk, stokAkun, pesan: req.query.pesan || null });
  } catch (err) { next(err); }
});

router.post('/produk/:id/restock', (req, res, next) => {
  try {
    const p = db.getProductById(Number(req.params.id));
    if (!p) return kembali(res, '/produk', 'Produk tidak ditemukan.');

    if (p.type === 'item') {
      const tambah = parsePositiveInt(req.body.jumlah || '');
      if (!tambah) return kembali(res, '/produk', 'Jumlah restock harus angka lebih dari 0.');
      db.restockItem(p.id, tambah);
      return kembali(res, '/produk', `Stok ${p.name} bertambah ${tambah}.`);
    }

    const blok = (req.body.data || '').split(/\n\s*\n/).map((s) => s.trim()).filter(Boolean);
    if (blok.length === 0) return kembali(res, '/produk', 'Belum ada data akun yang diisi.');
    db.restockAkun(p.id, blok);
    kembali(res, '/produk', `${blok.length} akun ditambahkan ke ${p.name}.`);
  } catch (err) { next(err); }
});

// ---------- ORDER (log, read-only) ----------
router.get('/order', (req, res, next) => {
  try {
    res.render('order', {
      title: 'Log Order',
      daftar: db.listOrders(req.query.status || undefined),
      statusAktif: req.query.status || '',
    });
  } catch (err) { next(err); }
});

// ---------- PEMBUKUAN (read-only) ----------
router.get('/pembukuan', (req, res, next) => {
  try {
    res.render('pembukuan', { title: 'Pembukuan', data: db.getPembukuan() });
  } catch (err) { next(err); }
});

// ---------- VOUCH & ROLE REWARD (read-only) ----------
router.get('/vouch', (req, res, next) => {
  try {
    res.render('vouch', {
      title: 'Vouch & Role Reward',
      vouches: db.listVouches(100),
      stats: db.getVouchStats(),
      rewards: db.listRoleRewards(),
    });
  } catch (err) { next(err); }
});

// ---------- PENGUMUMAN ----------
router.get('/pengumuman', (req, res, next) => {
  try {
    res.render('pengumuman', {
      title: 'Pengumuman',
      riwayat: db.listBroadcasts(),
      botStatus: db.getBotStatus(),
      pesan: req.query.pesan || null,
    });
  } catch (err) { next(err); }
});

router.post('/pengumuman', (req, res, next) => {
  try {
    const isi = (req.body.isi || '').trim();
    if (!isi) return kembali(res, '/pengumuman', 'Isi pengumuman tidak boleh kosong.');
    db.queueBroadcast((req.body.judul || '').trim() || null, isi);
    kembali(res, '/pengumuman', 'Pengumuman dititipkan. Bot akan mengirimkannya dalam beberapa detik.');
  } catch (err) { next(err); }
});

module.exports = router;
