// db.js
// Panel ini TIDAK punya database sendiri — ia membuka langsung file SQLite
// milik bot (yang sama persis dipakai bot Discord kamu) lewat DB_PATH di .env.
//
// Prinsip: read-only untuk hampir semua data (produk, order, pembukuan, vouch,
// role reward). Satu-satunya tulisan ke tabel INTI bot adalah:
//   - guild_config.store_status   (tombol Buka/Tutup Toko)
//   - products.stock              (tombol Restock)
//   - product_accounts            (restock produk tipe akun, insert baris baru)
// Ketiganya memakai kolom/tabel yang SUDAH ADA di bot — tidak ada ALTER TABLE,
// tidak ada tabel baru untuk data toko. Tidak ada logika order/produk/vouch
// yang diduplikasi di sini.
//
// Untuk fitur "Kirim Pengumuman", panel menitipkan pesan ke satu tabel kecil
// tambahan (web_broadcast_queue) yang dibaca bot lewat handlers/webPanel.js.
// Ini murni tambahan (additive) — tidak menyentuh satu pun kode/alur bot yang
// sudah ada. Kalau kamu belum menambahkan patch itu ke bot, tombol lain tetap
// berfungsi normal; hanya pengumuman yang akan tertunda sampai bot dipatch.

require('dotenv').config();

const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

function resolveDbPath() {
  if (process.env.DB_PATH && process.env.DB_PATH.trim() !== '') return process.env.DB_PATH.trim();
  // Path bawaan bot di Termux
  const dugaan = path.join(require('os').homedir(), 'storage', 'shared', 'storage-database');
  if (fs.existsSync(dugaan)) return dugaan;
  throw new Error(
    'DB_PATH belum diisi di .env dan database bot tidak ditemukan di lokasi bawaan. ' +
    'Isi DB_PATH dengan lokasi persis file "storage-database" milik bot kamu.',
  );
}

const dbPath = resolveDbPath();
if (!fs.existsSync(dbPath)) {
  throw new Error(`Database bot tidak ditemukan di "${dbPath}". Periksa DB_PATH di .env panel.`);
}

console.log(`[DB] Membuka database bot (read-only sebagian besar): ${dbPath}`);
const db = new Database(dbPath);
db.pragma('journal_mode = WAL');

// Tabel tambahan KHUSUS untuk fitur pengumuman & indikator online — tidak
// menyentuh tabel inti bot sama sekali.
db.exec(`
  CREATE TABLE IF NOT EXISTS web_broadcast_queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT NOT NULL,
    title TEXT,
    message TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'PENDING',
    error TEXT,
    created_at INTEGER NOT NULL,
    processed_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS web_panel_status (
    guild_id TEXT PRIMARY KEY,
    bot_tag TEXT,
    guild_name TEXT,
    last_seen INTEGER
  );
`);

// Server Discord yang dipantau. Kalau GUILD_ID tidak diisi di .env, panel
// otomatis memakai satu-satunya baris guild_config yang ada (kasus umum:
// bot cuma dipasang di satu server).
function resolveGuildId() {
  const dariEnv = (process.env.GUILD_ID || '').trim();
  if (dariEnv) return dariEnv;
  const baris = db.prepare('SELECT guild_id FROM guild_config LIMIT 1').get();
  if (!baris) throw new Error('Tabel guild_config kosong. Jalankan /setup di bot dulu, minimal sekali.');
  return baris.guild_id;
}

const GUILD_ID = resolveGuildId();
console.log(`[DB] Memantau server Discord: ${GUILD_ID}`);

// ---------- KONFIGURASI TOKO (baca dari bot, tulis hanya store_status) ----------
const getConfig = () => db.prepare('SELECT * FROM guild_config WHERE guild_id = ?').get(GUILD_ID);

function toggleStoreStatus() {
  const cfg = getConfig();
  const baru = cfg.store_status === 'OPEN' ? 'CLOSE' : 'OPEN';
  db.prepare('UPDATE guild_config SET store_status = ? WHERE guild_id = ?').run(baru, GUILD_ID);
  return baru;
}

// ---------- PRODUK (baca dari bot; tulis hanya stock & product_accounts) ----------
const listProducts = () => db.prepare('SELECT * FROM products WHERE guild_id = ? ORDER BY category, name').all(GUILD_ID);
const getProductById = (id) => db.prepare('SELECT * FROM products WHERE id = ? AND guild_id = ?').get(id, GUILD_ID);
const countAccountLines = (productId) =>
  db.prepare('SELECT COUNT(*) AS c FROM product_accounts WHERE product_id = ?').get(productId).c;

// Sama seperti fungsi addStockCount milik bot: cuma menambah angka stok.
function restockItem(productId, tambah) {
  const info = db.prepare('UPDATE products SET stock = stock + ? WHERE id = ? AND guild_id = ?').run(tambah, productId, GUILD_ID);
  if (info.changes === 0) throw new Error('Produk tidak ditemukan.');
}

// Sama seperti fungsi addAccountLines milik bot: insert baris akun + tambah stok.
function restockAkun(productId, lines) {
  const p = getProductById(productId);
  if (!p) throw new Error('Produk tidak ditemukan.');
  if (p.type !== 'akun') throw new Error('Produk ini bukan tipe akun.');
  const tx = db.transaction((arr) => {
    const ins = db.prepare('INSERT INTO product_accounts (product_id, content) VALUES (?, ?)');
    for (const isi of arr) ins.run(productId, isi);
    db.prepare('UPDATE products SET stock = stock + ? WHERE id = ?').run(arr.length, productId);
  });
  tx(lines);
}

// ---------- ORDER (murni baca, sama seperti query bot) ----------
const listOrders = (status) => (status
  ? db.prepare('SELECT * FROM orders WHERE guild_id = ? AND status = ? ORDER BY created_at DESC LIMIT 200').all(GUILD_ID, status)
  : db.prepare('SELECT * FROM orders WHERE guild_id = ? ORDER BY created_at DESC LIMIT 200').all(GUILD_ID));

const getPendingOrders = () => db.prepare(`SELECT * FROM orders WHERE guild_id = ? AND status = 'PENDING' ORDER BY created_at ASC`).all(GUILD_ID);

// ---------- PEMBUKUAN (query sama persis dengan command /pembukuan bot) ----------
function getPembukuan() {
  const omset = db.prepare(`SELECT COALESCE(SUM(total_price), 0) AS total FROM orders WHERE guild_id = ? AND status = 'SUCCESS'`).get(GUILD_ID).total;
  const sukses = db.prepare(`SELECT COUNT(*) AS c FROM orders WHERE guild_id = ? AND status = 'SUCCESS'`).get(GUILD_ID).c;
  const gagal = db.prepare(`SELECT COUNT(*) AS c FROM orders WHERE guild_id = ? AND status IN ('BATAL','EXPIRED')`).get(GUILD_ID).c;
  const pending = db.prepare(`SELECT COUNT(*) AS c FROM orders WHERE guild_id = ? AND status = 'PENDING'`).get(GUILD_ID).c;
  const terlaris = db.prepare(`
    SELECT product_name, SUM(quantity) AS total_qty, SUM(total_price) AS total_omset
    FROM orders WHERE guild_id = ? AND status = 'SUCCESS'
    GROUP BY product_name ORDER BY total_qty DESC LIMIT 5
  `).all(GUILD_ID);
  const harian = db.prepare(`
    SELECT strftime('%d-%m', created_at / 1000, 'unixepoch', '+7 hours') AS hari,
           COALESCE(SUM(total_price), 0) AS total
    FROM orders WHERE guild_id = ? AND status = 'SUCCESS'
    GROUP BY hari ORDER BY created_at DESC LIMIT 7
  `).all(GUILD_ID);
  return { omset, sukses, gagal, pending, terlaris, harian: harian.reverse() };
}

// ---------- VOUCH & ROLE REWARD (murni baca) ----------
const listVouches = (limit = 50) => db.prepare(`
  SELECT v.*, o.order_code, o.product_name, o.total_price, o.buyer_username
  FROM vouches v LEFT JOIN orders o ON o.id = v.order_id
  WHERE v.guild_id = ? ORDER BY v.created_at DESC LIMIT ?
`).all(GUILD_ID, limit);

const getVouchStats = () => {
  const r = db.prepare('SELECT COUNT(*) AS jumlah, COALESCE(AVG(rating), 0) AS rata FROM vouches WHERE guild_id = ?').get(GUILD_ID);
  return { jumlah: r.jumlah, rata: Math.round(r.rata * 10) / 10 };
};

const listRoleRewards = () => db.prepare('SELECT * FROM role_rewards WHERE guild_id = ? ORDER BY min_spending ASC').all(GUILD_ID);

// ---------- PENGUMUMAN (tabel tambahan, bukan bagian sistem inti bot) ----------
function queueBroadcast(title, message) {
  db.prepare(`INSERT INTO web_broadcast_queue (guild_id, title, message, status, created_at) VALUES (?, ?, ?, 'PENDING', ?)`)
    .run(GUILD_ID, title || null, message, Date.now());
}

const listBroadcasts = (limit = 15) =>
  db.prepare('SELECT * FROM web_broadcast_queue WHERE guild_id = ? ORDER BY id DESC LIMIT ?').all(GUILD_ID, limit);

// ---------- STATUS BOT (online/offline) ----------
function getBotStatus() {
  const row = db.prepare('SELECT * FROM web_panel_status WHERE guild_id = ?').get(GUILD_ID);
  if (!row) return { terhubung: false };
  return { terhubung: Date.now() - row.last_seen < 60000, ...row };
}

module.exports = {
  GUILD_ID,
  getConfig, toggleStoreStatus,
  listProducts, getProductById, countAccountLines, restockItem, restockAkun,
  listOrders, getPendingOrders,
  getPembukuan,
  listVouches, getVouchStats, listRoleRewards,
  queueBroadcast, listBroadcasts,
  getBotStatus,
};
