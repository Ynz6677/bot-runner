# Cara memasang patch pengumuman (opsional)

Folder ini BUKAN bot lengkap — cuma potongan kecil untuk fitur "Kirim
Pengumuman" di panel. Restock dan buka/tutup toko TIDAK butuh apa pun dari
folder ini, sudah langsung berfungsi.

1. Salin `handlers/webPanel.js` ke folder `handlers/` bot kamu yang asli.
2. Bandingkan `database.js.contoh-setelah-dipatch` dengan `database.js` bot
   kamu (pakai `diff` atau baca manual) — tambahkan HANYA blok yang diawali
   komentar `JEMBATAN PANEL WEB` di bagian bawah, sebelum `module.exports`,
   dan tambahkan 3 nama fungsi baru ke dalam `module.exports`. Jangan hapus
   atau ubah baris lain.
3. Bandingkan `ready.js.contoh-setelah-dipatch` dengan `events/ready.js` bot
   kamu — cuma ada 2 baris tambahan: `require` di atas dan `webPanel.start(client)`
   di dalam fungsi `execute`.
4. Restart bot.

Kalau ragu, kirimkan isi `database.js` dan `ready.js` bot kamu yang asli,
biar saya buatkan diff yang pasti aman untuk versi kamu.
