// handlers/webPanel.js
// Jembatan MINIMAL ke Panel Web. File ini TIDAK menyentuh satu pun logika
// order, produk, stok, atau vouch yang sudah ada — kalau file ini dihapus dan
// baris pemanggilannya di events/ready.js dibuang, bot berjalan 100% seperti
// sebelum panel ada.
//
// Tugasnya cuma dua, keduanya lewat koneksi database yang SAMA dengan bot
// (lihat database.js, bagian "JEMBATAN PANEL WEB"):
//   1. Menulis "denyut nadi" tiap 15 detik supaya panel tahu bot online.
//   2. Membaca antrean pengumuman tiap 5 detik, mengirimkannya sebagai embed
//      ke Channel Info Toko (channel yang sama dipakai /setup).

const { EmbedBuilder } = require('discord.js');
const db = require('../database');
const config = require('../config.json');

const POLL_MS = 5000;
const HEARTBEAT_MS = 15000;

async function kirimPengumuman(guild, tugas) {
  const cfg = db.getGuildConfig(guild.id);
  if (!cfg?.info_channel_id) throw new Error('Channel Info Toko belum diatur. Jalankan /setup dulu.');

  const channel = await guild.channels.fetch(cfg.info_channel_id).catch(() => null);
  if (!channel) throw new Error('Channel Info Toko tidak ditemukan (mungkin sudah dihapus).');

  const embed = new EmbedBuilder()
    .setColor(config.embed_color)
    .setTitle(tugas.title || '📢 Pengumuman')
    .setDescription(tugas.message)
    .setFooter({ text: 'Dikirim lewat Panel Web' })
    .setTimestamp();

  await channel.send({ embeds: [embed] });
}

async function prosesPengumuman(client) {
  for (const guild of client.guilds.cache.values()) {
    const tugasList = db.takeBroadcastQueue(guild.id);
    for (const tugas of tugasList) {
      try {
        // eslint-disable-next-line no-await-in-loop
        await kirimPengumuman(guild, tugas);
        db.markBroadcastDone(tugas.id, 'DONE');
      } catch (err) {
        console.error('[webPanel] Gagal mengirim pengumuman:', err.message);
        db.markBroadcastDone(tugas.id, 'ERROR', err.message);
      }
    }
  }
}

function denyutNadi(client) {
  for (const guild of client.guilds.cache.values()) {
    db.writePanelHeartbeat(guild.id, client.user.tag, guild.name);
  }
}

function start(client) {
  denyutNadi(client);
  setInterval(() => denyutNadi(client), HEARTBEAT_MS);
  setInterval(() => prosesPengumuman(client).catch((err) => console.error('[webPanel]', err.message)), POLL_MS);
  console.log('[webPanel] Jembatan Panel Web aktif (pengumuman + status online). Sistem toko tidak diubah.');
}

module.exports = { start };
