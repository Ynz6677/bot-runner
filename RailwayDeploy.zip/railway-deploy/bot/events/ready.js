const config = require('../config.json');
const { expireOldOrders } = require('../handlers/orderManager');
const webPanel = require('../handlers/webPanel');

module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    console.log(`[BOT] Login sebagai ${client.user.tag}`);
    client.user.setPresence({ activities: [{ name: 'Toko Online 🛒' }], status: 'online' });

    // Jembatan Panel Web (opsional): kirim pengumuman yang dititipkan lewat
    // panel + status online. Tidak mengubah alur order/produk/vouch di atas.
    webPanel.start(client);

    // Jalankan pengecekan order timeout (anti-spam 1 jam) secara berkala.
    // Menggunakan interval + cek created_at di DB (bukan setTimeout per-order)
    // supaya tetap aman/akurat walau proses bot sempat restart di Termux.
    setInterval(() => {
      expireOldOrders(client).catch((err) => console.error('[ready] Gagal proses expire order:', err));
    }, config.order_expire_check_interval_ms || 60000);

    // Jalankan sekali di awal juga, untuk membersihkan order yang expired saat bot offline
    expireOldOrders(client).catch((err) => console.error('[ready] Gagal proses expire order awal:', err));
  },
};
