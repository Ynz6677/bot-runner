const buttons = require('../handlers/buttons');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {
    try {
      if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);
        if (!command) return;
        await command.execute(interaction, client);
        return;
      }

      if (interaction.isAutocomplete()) {
        const command = client.commands.get(interaction.commandName);
        if (!command || !command.autocomplete) return;
        await command.autocomplete(interaction, client);
        return;
      }

      if (interaction.isButton()) {
        await buttons.handle(interaction, client);
        return;
      }
      // Catatan: interaksi StringSelectMenu & ModalSubmit dari alur admin_panel
      // ditangani langsung di dalam handlers/buttons.js via awaitMessageComponent /
      // awaitModalSubmit, jadi tidak perlu router terpisah di sini.
    } catch (err) {
      console.error('[interactionCreate] Error:', err);
      const payload = { content: '❌ Terjadi kesalahan saat memproses interaksi ini.', ephemeral: true };
      try {
        if (interaction.deferred || interaction.replied) {
          await interaction.followUp(payload);
        } else {
          await interaction.reply(payload);
        }
      } catch (_) {
        // interaksi mungkin sudah expired, abaikan
      }
    }
  },
};
