// handlers/deliveryManager.js
const { AttachmentBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const db = require('../database');
const config = require('../config.json');
const { formatRupiah } = require('../utils/helpers');
const { formatWIB } = require('../utils/time');
const { generateReceiptImage } = require('./receiptGenerator');
const { statusLogText } = require('./orderManager');

function buildVouchButton(orderDbId) {
  const vouchBtnCfg = config.buttons.berikan_vouch;
  const vouchButton = new ButtonBuilder()
    .setCustomId(`vouch_${orderDbId}`)
    .setLabel(vouchBtnCfg.label)
    .setStyle(ButtonStyle[vouchBtnCfg.style] || ButtonStyle.Primary);
  if (vouchBtnCfg.emoji) vouchButton.setEmoji(vouchBtnCfg.emoji);
  return new ActionRowBuilder().addComponents(vouchButton);
}

// Memberikan role reward otomatis kalau TOTAL NOMINAL BELANJA pembeli sudah memenuhi
// salah satu (atau lebih) ambang batas yang diatur admin lewat /role_rewards.
async function grantRoleRewards(guild, buyerId) {
  try {
    const totalSpending = db.getTotalSpending(guild.id, buyerId);
    const rewards = db.listRoleRewards(guild.id).filter((r) => totalSpending >= r.min_spending);
    if (rewards.length === 0) return;

    const member = await guild.members.fetch(buyerId).catch(() => null);
    if (!member) return;

    for (const reward of rewards) {
      if (!member.roles.cache.has(reward.role_id)) {
        await member.roles.add(reward.role_id).catch((err) => console.error('[deliveryManager] Gagal kasih role reward:', err.message));
      }
    }
  } catch (err) {
    console.error('[deliveryManager] Gagal cek role reward:', err.message);
  }
}

// Menyelesaikan order SUKSES: update status di channel admin, log publik, generate+DM nota,
// kunci channel order (tidak bisa chat lagi) TAPI TIDAK dihapus sampai pembeli memberi vouch.
async function finalizeSuccess(client, order, statusMessage) {
  db.updateOrderStatus(order.id, 'SUCCESS');

  const guild = await client.guilds.fetch(order.guild_id);
  const cfg = db.getGuildConfig(order.guild_id);
  const tanggal = formatWIB(new Date());

  // 1) Update teks STATUS di channel admin -> BERHASIL, & hilangkan tombol (anti double-klik)
  if (statusMessage) {
    const newText = statusLogText(order.order_code, order.usn, order.product_name, 'BERHASIL');
    await statusMessage.edit({ content: `${newText}\nChannel: <#${order.channel_id}>`, components: [] }).catch(() => {});
  }

  // 2) Log ke channel riwayat publik
  const logChannel = cfg.log_channel_id ? await guild.channels.fetch(cfg.log_channel_id).catch(() => null) : null;
  if (logChannel) {
    const logText =
      `**${order.product_name}**\n` +
      `-# ${tanggal} WIB\n` +
      '```\n' +
      `USN    : ${order.usn}\n` +
      `ORDER  : ${order.product_name}\n` +
      `JUMLAH : ${order.quantity}\n` +
      `HARGA  : ${formatRupiah(order.total_price)}\n` +
      `STATUS : BERHASIL\n` +
      '```';
    await logChannel.send(logText).catch(() => {});
  }

  // 3) Catat ke ledger pembukuan (NO tetap kontinu walau nanti di-export & "direset")
  db.insertLedger({
    guildId: order.guild_id,
    usn: order.usn,
    orderName: order.product_name,
    buyerId: order.buyer_id,
    tanggal,
    orderCode: order.order_code,
    totalPrice: order.total_price,
  });

  // 4) Kunci channel order: buyer tidak bisa chat lagi, tapi channel TIDAK dihapus otomatis
  //    (baru dihapus setelah pembeli memberikan vouch - lihat handlers/buttons.js customId vouch_)
  const ticketChannel = await guild.channels.fetch(order.channel_id).catch(() => null);
  if (ticketChannel) {
    await ticketChannel.permissionOverwrites.edit(order.buyer_id, { SendMessages: false }).catch(() => {});
    await ticketChannel.send({
      content: `${config.messages.ticket_locked_notice}\n\n${config.messages.vouch_ticket_text}`,
      components: [buildVouchButton(order.id)],
    }).catch(() => {});
  }

  // 5) Generate gambar nota & kirim via DM ke pembeli
  try {
    const buyer = await client.users.fetch(order.buyer_id);
    const receiptBuffer = generateReceiptImage({
      orderId: order.order_code,
      usn: order.usn,
      orderName: order.product_name,
      jumlah: order.quantity,
      hargaTotal: order.total_price,
      hargaSatuan: order.total_price / order.quantity,
      tanggalWIB: `${tanggal} WIB`,
      serverName: guild.name,
    });
    const attachment = new AttachmentBuilder(receiptBuffer, { name: `nota-${order.order_code}.png` });
    await buyer.send({ content: `🧾 Berikut nota pembelian kamu untuk order **${order.product_name}** (BERHASIL):`, files: [attachment] });

    // Khusus tipe "Akun": kirim data akun otomatis via DM, lalu hapus dari DB
    if (order.product_type === 'akun') {
      const accounts = db.popAccountLines(order.product_id, order.quantity);
      const isi = accounts.map((a, i) => `#${i + 1}\n${a}`).join('\n\n');
      await buyer.send(`🔐 Berikut data akun untuk pesanan **${order.product_name}** kamu:\n\`\`\`\n${isi}\n\`\`\``);
    }
  } catch (err) {
    console.error('[deliveryManager] Gagal generate/kirim nota ke pembeli:', err.message);
  }

  // 6) Role reward otomatis berdasarkan total nominal belanja (kalau ada yang sudah tercapai)
  await grantRoleRewards(guild, order.buyer_id);
}

// Owner/Admin menekan tombol [Berhasil] di CHANNEL ADMIN (bukan channel order pembeli)
async function confirmSukses(interaction, orderId) {
  const order = db.getOrderById(orderId);
  if (!order || order.status !== 'PENDING') {
    return interaction.reply({ content: '⚠️ Order ini sudah tidak berstatus MENUNGGU KONFIRMASI (mungkin sudah diproses/dibatalkan).', ephemeral: true });
  }

  await interaction.deferReply({ ephemeral: true });
  await finalizeSuccess(interaction.client, order, interaction.message);
  await interaction.editReply({ content: `✅ Order **${order.order_code}** dikonfirmasi BERHASIL. Nota sudah dikirim ke pembeli. Channel order dikunci & akan otomatis terhapus setelah pembeli memberikan vouch.` });
}

// Owner/Admin menekan tombol [Dibatalkan] di CHANNEL ADMIN
async function batalkanOrder(interaction, orderId) {
  const order = db.getOrderById(orderId);
  if (!order || order.status !== 'PENDING') {
    return interaction.reply({ content: '⚠️ Order ini sudah tidak bisa dibatalkan.', ephemeral: true });
  }

  await interaction.deferReply({ ephemeral: true });

  db.updateOrderStatus(orderId, 'BATAL');
  db.restoreStock(order.product_id, order.quantity);
  // Ketentuan: TIDAK ada notifikasi DM apapun ke pembeli saat dibatalkan

  // Update teks STATUS di channel admin -> DIBATALKAN, & hilangkan tombol
  const newText = statusLogText(order.order_code, order.usn, order.product_name, 'DIBATALKAN');
  await interaction.message.edit({ content: `${newText}\nChannel: <#${order.channel_id}>`, components: [] }).catch(() => {});

  // Hapus channel order pembeli (order tidak jadi/void)
  try {
    const guild = interaction.guild;
    const channel = await guild.channels.fetch(order.channel_id).catch(() => null);
    if (channel) {
      await channel.send('❌ Order dibatalkan oleh Admin. Channel ini akan dihapus.').catch(() => {});
      setTimeout(() => channel.delete().catch(() => {}), 5000);
    }
  } catch (err) {
    console.error('[deliveryManager] Gagal menghapus channel saat dibatalkan:', err.message);
  }

  await interaction.editReply({ content: `✅ Order **${order.order_code}** dibatalkan & stok telah dikembalikan.` });
}

module.exports = { confirmSukses, batalkanOrder, finalizeSuccess };
