// handlers/buttons.js
// Semua interaksi tombol (ButtonInteraction) di-dispatch dari sini.
// Alur select-menu & modal ditangani langsung di sini via awaitMessageComponent/awaitModalSubmit
// supaya logika tiap fitur tetap menyatu & mudah dilacak.

const {
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ChannelSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  EmbedBuilder,
} = require('discord.js');

const db = require('../database');
const config = require('../config.json');
const { isAdmin, requireAdmin } = require('../utils/permissions');
const { parsePositiveInt, formatRupiah, toChannelSafeName } = require('../utils/helpers');
const { confirmSukses, batalkanOrder } = require('./deliveryManager');
const { startOrderFlow } = require('./orderManager');
const { buildProductEmbed } = require('../commands/katalog');

// Hapus pesan katalog lama (jika ada) & kirim ulang sebagai chat baru - dipakai oleh Restok & Upload Akun
async function republishProductCatalog(guild, product) {
  if (!product.channel_id) return;
  try {
    const prodChannel = await guild.channels.fetch(product.channel_id).catch(() => null);
    if (!prodChannel) return;
    if (product.message_id) {
      const oldMsg = await prodChannel.messages.fetch(product.message_id).catch(() => null);
      if (oldMsg) await oldMsg.delete().catch(() => {});
    }
    const refreshedProduct = db.getProductById(product.id);
    const newMsg = await prodChannel.send({ embeds: [buildProductEmbed(refreshedProduct)] });
    db.setProductMessage(product.id, product.channel_id, newMsg.id);
  } catch (err) {
    console.error('[buttons] Gagal republish katalog produk:', err.message);
  }
}

// Alur "pilih channel tujuan" (buat channel baru / pakai yang sudah ada) - dipakai oleh TAMBAHKAN & Upload Akun.
// Mengembalikan { targetChannel, modalTrigger } atau null jika dibatalkan/gagal (pesan error sudah dikirim di sini).
async function pickTargetChannel(interaction) {
  const stepRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('tambah_channel_baru').setLabel(config.buttons.buat_channel_baru.label).setEmoji(config.buttons.buat_channel_baru.emoji).setStyle(ButtonStyle[config.buttons.buat_channel_baru.style]),
    new ButtonBuilder().setCustomId('tambah_channel_pilih').setLabel(config.buttons.pilih_channel_ada.label).setEmoji(config.buttons.pilih_channel_ada.emoji).setStyle(ButtonStyle[config.buttons.pilih_channel_ada.style]),
  );
  const stepReply = await interaction.reply({
    content: '📂 Barang ini mau dipublikasikan ke channel yang mana?',
    components: [stepRow],
    ephemeral: true,
    fetchReply: true,
  });
  const stepInteraction = await stepReply.awaitMessageComponent({ time: 60000, filter: (i) => i.user.id === interaction.user.id }).catch(() => null);
  if (!stepInteraction) return null;

  if (stepInteraction.customId === 'tambah_channel_baru') {
    const nameModal = new ModalBuilder().setCustomId('modal_nama_channel_baru').setTitle('Nama Channel Baru');
    nameModal.addComponents(
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('nama_channel').setLabel('Nama Channel').setStyle(TextInputStyle.Short).setRequired(true)),
    );
    await stepInteraction.showModal(nameModal);
    const nameSubmit = await stepInteraction.awaitModalSubmit({ time: 60000, filter: (i) => i.customId === 'modal_nama_channel_baru' }).catch(() => null);
    if (!nameSubmit) return null;

    const namaChannel = nameSubmit.fields.getTextInputValue('nama_channel').trim();

    const categorySelect = new ChannelSelectMenuBuilder().setCustomId('select_parent_category').setPlaceholder('Pilih kategori channel').addChannelTypes(ChannelType.GuildCategory);
    const skipCategoryButton = new ButtonBuilder().setCustomId('skip_category').setLabel('Tanpa Kategori').setStyle(ButtonStyle.Secondary).setEmoji('🚫');
    const catReply = await nameSubmit.reply({
      content: `📁 Channel **${namaChannel}** mau diletakkan di kategori mana?`,
      components: [new ActionRowBuilder().addComponents(categorySelect), new ActionRowBuilder().addComponents(skipCategoryButton)],
      ephemeral: true,
      fetchReply: true,
    });
    const catPicked = await catReply.awaitMessageComponent({ time: 60000, filter: (i) => i.user.id === interaction.user.id }).catch(() => null);
    if (!catPicked) return null;

    const parentCategoryId = catPicked.customId === 'skip_category' ? undefined : catPicked.values[0];

    try {
      const targetChannel = await interaction.guild.channels.create({
        name: toChannelSafeName(namaChannel),
        type: ChannelType.GuildText,
        parent: parentCategoryId,
      });
      return { targetChannel, modalTrigger: catPicked };
    } catch (err) {
      await catPicked.reply({ content: `❌ Gagal membuat channel baru: ${err.message}. Cek permission bot (Manage Channels).`, ephemeral: true }).catch(() => {});
      return null;
    }
  }

  if (stepInteraction.customId === 'tambah_channel_pilih') {
    const channelSelect = new ChannelSelectMenuBuilder().setCustomId('select_target_channel').setPlaceholder('Pilih channel tujuan').addChannelTypes(ChannelType.GuildText);
    await stepInteraction.update({ content: '📂 Pilih channel tujuan publikasi barang:', components: [new ActionRowBuilder().addComponents(channelSelect)] });

    const channelPicked = await stepReply.awaitMessageComponent({ time: 60000, filter: (i) => i.user.id === interaction.user.id }).catch(() => null);
    if (!channelPicked) return null;

    const targetChannel = await interaction.guild.channels.fetch(channelPicked.values[0]).catch(() => null);
    if (!targetChannel) {
      // BUGFIX: sebelumnya di sini langsung "return" tanpa pesan apapun kalau channel gagal di-fetch,
      // sehingga admin merasa barang "tidak ter-upload" tanpa tahu penyebabnya.
      await channelPicked.reply({ content: '❌ Channel yang dipilih tidak ditemukan/tidak bisa diakses bot. Coba pilih channel lain.', ephemeral: true }).catch(() => {});
      return null;
    }
    return { targetChannel, modalTrigger: channelPicked };
  }

  return null;
}

// Jeda 3 detik + info, LALU benar-benar menunggu foto manual dari admin (jika dikirim) sebelum publish.
// BUGFIX: versi sebelumnya cuma bilang "kirim foto manual" tanpa pernah menangkap fotonya sama sekali,
// jadi foto yang dikirim admin tidak pernah kesimpan/terpasang ke produk.
async function publishNewProduct(submittedInteraction, product) {
  // PENTING: Discord mewajibkan interaksi di-ACK (reply/deferReply) dalam 3 detik.
  // Sebelumnya ada jeda 3 detik SEBELUM reply() di sini -> interaksi keburu expired,
  // reply() gagal (error "Unknown interaction"), dan seluruh proses publish di bawahnya
  // ikut batal walau produknya sendiri sudah kepalang tersimpan di database.
  await submittedInteraction.reply({ content: 'produk sudah di tambahkan, untuk foto kirim secara manual!', ephemeral: true });

  const filter = (m) => m.author.id === submittedInteraction.user.id && m.attachments.size > 0;
  const collected = await submittedInteraction.channel.awaitMessages({ filter, max: 1, time: 45000 }).catch(() => null);
  if (collected && collected.size > 0) {
    const msg = collected.first();
    const attachment = msg.attachments.find((a) => a.contentType?.startsWith('image/'));
    if (attachment) db.setProductImage(product.id, attachment.url);
    await msg.delete().catch(() => {});
  }

  const targetChannel = await submittedInteraction.guild.channels.fetch(product.channel_id).catch(() => null);
  if (!targetChannel) {
    await submittedInteraction.followUp({ content: '❌ Channel publikasi tidak ditemukan lagi, produk tersimpan di database tapi belum dipublikasikan.', ephemeral: true }).catch(() => {});
    return;
  }
  const freshProduct = db.getProductById(product.id);
  const publishedMsg = await targetChannel.send({ embeds: [buildProductEmbed(freshProduct)] });
  db.setProductMessage(product.id, targetChannel.id, publishedMsg.id);
  await submittedInteraction.followUp({ content: `🎉 Barang **${product.name}** berhasil dipublikasikan di <#${targetChannel.id}>.`, ephemeral: true }).catch(() => {});
}

async function handle(interaction, client) {
  const id = interaction.customId;

  // ================== TOMBOL ORDER (dipasang lewat /order place) ==================
  if (id.startsWith('order_panel_')) {
    const panelId = Number(id.slice('order_panel_'.length));
    const panel = db.getOrderPanel(panelId);
    if (!panel) {
      return interaction.reply({ content: '❌ Tombol ini sudah tidak valid (konfigurasi tidak ditemukan). Minta admin membuat ulang lewat `/order place`.', ephemeral: true });
    }
    await startOrderFlow(interaction, { type: panel.type, categoryId: panel.category_id });
    return;
  }

  // ================== ADMIN PANEL: TAMBAHKAN (barang baru, selalu tipe Item) ==================
  if (id === 'admin_tambah_barang') {
    if (!(await requireAdmin(interaction))) return;

    const picked = await pickTargetChannel(interaction);
    if (!picked) return;
    const { targetChannel, modalTrigger } = picked;

    // Modal detail barang -> Nama, Harga, Stok (tipe SELALU "item", tanpa perlu diketik)
    const itemModal = new ModalBuilder().setCustomId('modal_tambah_barang').setTitle('Detail Barang (Item)');
    itemModal.addComponents(
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('nama').setLabel('Nama Produk').setStyle(TextInputStyle.Short).setRequired(true)),
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('harga').setLabel('Harga (angka saja)').setStyle(TextInputStyle.Short).setRequired(true)),
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('stok').setLabel('Stok Awal (angka saja)').setStyle(TextInputStyle.Short).setRequired(true)),
    );
    await modalTrigger.showModal(itemModal);

    const itemSubmit = await modalTrigger.awaitModalSubmit({ time: 120000, filter: (i) => i.customId === 'modal_tambah_barang' }).catch(() => null);
    if (!itemSubmit) return;

    const nama = itemSubmit.fields.getTextInputValue('nama').trim();
    const harga = parsePositiveInt(itemSubmit.fields.getTextInputValue('harga'));
    const stokRaw = itemSubmit.fields.getTextInputValue('stok');
    const stok = parsePositiveInt(stokRaw) ?? (stokRaw.trim() === '0' ? 0 : null);

    if (harga === null) return itemSubmit.reply({ content: '❌ Harga harus berupa angka bulat positif.', ephemeral: true });
    if (stok === null) return itemSubmit.reply({ content: '❌ Stok harus berupa angka bulat (boleh 0 atau lebih).', ephemeral: true });

    let product;
    try {
      product = db.addProduct({
        guildId: interaction.guildId,
        name: nama,
        price: harga,
        stock: stok,
        type: 'item',
        category: targetChannel.name,
        channelId: targetChannel.id,
      });
    } catch (err) {
      return itemSubmit.reply({ content: `❌ ${err.message}`, ephemeral: true });
    }

    await publishNewProduct(itemSubmit, product);
    return;
  }

  // ================== ADMIN PANEL: RESTOK (khusus tipe Item) ==================
  if (id === 'admin_restok') {
    if (!(await requireAdmin(interaction))) return;
    const products = db.listProductsByType(interaction.guildId, 'item');
    if (products.length === 0) return interaction.reply({ content: '⚠️ Belum ada produk tipe Item. Tambahkan produk dulu.', ephemeral: true });

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('select_restok')
      .setPlaceholder('Pilih produk yang mau di-restok')
      .addOptions(products.slice(0, 25).map((p) => ({ label: `${p.name} (stok: ${p.stock})`, value: String(p.id) })));

    const reply = await interaction.reply({ components: [new ActionRowBuilder().addComponents(selectMenu)], ephemeral: true, fetchReply: true });
    const selectInteraction = await reply.awaitMessageComponent({ time: 60000, filter: (i) => i.user.id === interaction.user.id }).catch(() => null);
    if (!selectInteraction) return;

    const product = db.getProductById(Number(selectInteraction.values[0]));
    if (!product) return selectInteraction.reply({ content: '❌ Produk tidak ditemukan.', ephemeral: true });

    const modal = new ModalBuilder().setCustomId(`modal_restok_${product.id}`).setTitle(`Restok: ${product.name}`.slice(0, 45));
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('jumlah_stok').setLabel('Jumlah Stok Ditambahkan').setStyle(TextInputStyle.Short).setRequired(true),
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('pesan_custom').setLabel('Pesan Chat Custom (broadcast)').setStyle(TextInputStyle.Paragraph).setRequired(true),
      ),
    );
    await selectInteraction.showModal(modal);

    const submitted = await selectInteraction.awaitModalSubmit({ time: 180000, filter: (i) => i.customId === `modal_restok_${product.id}` }).catch(() => null);
    if (!submitted) return;

    const pesanCustom = submitted.fields.getTextInputValue('pesan_custom').trim();
    const jumlah = parsePositiveInt(submitted.fields.getTextInputValue('jumlah_stok'));
    if (jumlah === null) return submitted.reply({ content: '❌ Jumlah stok harus angka bulat positif.', ephemeral: true });
    db.addStockCount(product.id, jumlah);

    await republishProductCatalog(interaction.guild, product);
    await submitted.reply({ content: `✅ Stok **${product.name}** berhasil ditambah ${jumlah}.`, ephemeral: true });

    const embed = new EmbedBuilder()
      .setColor(config.embed_color)
      .setTitle(`📦 Restok: ${product.name}`)
      .setDescription(pesanCustom)
      .addFields({ name: 'Stok Ditambahkan', value: String(jumlah), inline: true })
      .setTimestamp();

    const cfgRestok = db.getGuildConfig(interaction.guildId);
    if (cfgRestok?.info_channel_id) {
      const guild = await client.guilds.fetch(interaction.guildId);
      const infoChannel = await guild.channels.fetch(cfgRestok.info_channel_id).catch(() => null);
      if (infoChannel) await infoChannel.send({ embeds: [embed] }).catch(() => {});
    }
    return;
  }

  // ================== ADMIN PANEL: UPLOAD AKUN (khusus tipe Akun, bisa buat produk baru) ==================
  if (id === 'admin_upload_akun') {
    if (!(await requireAdmin(interaction))) return;
    const products = db.listProductsByType(interaction.guildId, 'akun');

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('select_upload_akun')
      .setPlaceholder('Pilih produk Akun (atau buat baru)')
      .addOptions([
        { label: '➕ Buat Produk Akun Baru', value: '__new__' },
        ...products.slice(0, 24).map((p) => ({ label: `${p.name} (stok: ${p.stock})`, value: String(p.id) })),
      ]);

    const reply = await interaction.reply({ components: [new ActionRowBuilder().addComponents(selectMenu)], ephemeral: true, fetchReply: true });
    const selectInteraction = await reply.awaitMessageComponent({ time: 60000, filter: (i) => i.user.id === interaction.user.id }).catch(() => null);
    if (!selectInteraction) return;

    // ---- Buat produk Akun baru ----
    if (selectInteraction.values[0] === '__new__') {
      const picked = await pickTargetChannel(selectInteraction);
      if (!picked) return;
      const { targetChannel, modalTrigger } = picked;

      const modal = new ModalBuilder().setCustomId('modal_akun_baru').setTitle('Produk Akun Baru');
      modal.addComponents(
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('nama').setLabel('Nama Produk').setStyle(TextInputStyle.Short).setRequired(true)),
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('harga').setLabel('Harga (angka saja)').setStyle(TextInputStyle.Short).setRequired(true)),
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('usn').setLabel('USN').setStyle(TextInputStyle.Short).setRequired(true)),
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('email').setLabel('EMAIL').setStyle(TextInputStyle.Short).setRequired(true)),
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('password').setLabel('PASSWORD').setStyle(TextInputStyle.Short).setRequired(true)),
      );
      await modalTrigger.showModal(modal);

      const submitted = await modalTrigger.awaitModalSubmit({ time: 120000, filter: (i) => i.customId === 'modal_akun_baru' }).catch(() => null);
      if (!submitted) return;

      const nama = submitted.fields.getTextInputValue('nama').trim();
      const harga = parsePositiveInt(submitted.fields.getTextInputValue('harga'));
      const usn = submitted.fields.getTextInputValue('usn').trim();
      const email = submitted.fields.getTextInputValue('email').trim();
      const password = submitted.fields.getTextInputValue('password').trim();

      if (harga === null) return submitted.reply({ content: '❌ Harga harus berupa angka bulat positif.', ephemeral: true });

      let product;
      try {
        product = db.addProduct({
          guildId: interaction.guildId,
          name: nama,
          price: harga,
          stock: 1,
          type: 'akun',
          category: targetChannel.name,
          channelId: targetChannel.id,
        });
      } catch (err) {
        return submitted.reply({ content: `❌ ${err.message}`, ephemeral: true });
      }

      db.addAccountLines(product.id, [`USN: ${usn}\nEMAIL: ${email}\nPASSWORD: ${password}\nDESKRIPSI: -`]);
      await publishNewProduct(submitted, product);
      return;
    }

    // ---- Tambah akun ke produk yang sudah ada ----
    const product = db.getProductById(Number(selectInteraction.values[0]));
    if (!product) return selectInteraction.reply({ content: '❌ Produk tidak ditemukan.', ephemeral: true });

    const modal = new ModalBuilder().setCustomId(`modal_upload_akun_${product.id}`).setTitle(`Upload Akun: ${product.name}`.slice(0, 45));
    modal.addComponents(
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('usn').setLabel('USN').setStyle(TextInputStyle.Short).setRequired(true)),
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('email').setLabel('EMAIL').setStyle(TextInputStyle.Short).setRequired(true)),
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('password').setLabel('PASSWORD').setStyle(TextInputStyle.Short).setRequired(true)),
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('deskripsi').setLabel('DESKRIPSI').setStyle(TextInputStyle.Paragraph).setRequired(false)),
    );
    await selectInteraction.showModal(modal);

    const submitted = await selectInteraction.awaitModalSubmit({ time: 180000, filter: (i) => i.customId === `modal_upload_akun_${product.id}` }).catch(() => null);
    if (!submitted) return;

    const usn = submitted.fields.getTextInputValue('usn').trim();
    const email = submitted.fields.getTextInputValue('email').trim();
    const password = submitted.fields.getTextInputValue('password').trim();
    const deskripsi = submitted.fields.getTextInputValue('deskripsi')?.trim() || '-';
    const content = `USN: ${usn}\nEMAIL: ${email}\nPASSWORD: ${password}\nDESKRIPSI: ${deskripsi}`;

    db.addAccountLines(product.id, [content]);
    db.addStockCount(product.id, 1);
    await republishProductCatalog(interaction.guild, product);

    await submitted.reply({ content: `✅ 1 akun berhasil ditambahkan ke **${product.name}**. Stok sekarang: ${product.stock + 1}.`, ephemeral: true });
    return;
  }

  // ================== ADMIN PANEL: UBAH INFO / HARGA ==================
  if (id === 'admin_ubahharga') {
    if (!(await requireAdmin(interaction))) return;
    const products = db.listProducts(interaction.guildId);
    if (products.length === 0) return interaction.reply({ content: '⚠️ Belum ada produk.', ephemeral: true });

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('select_ubahharga')
      .setPlaceholder('Pilih produk yang mau diubah harganya')
      .addOptions(products.slice(0, 25).map((p) => ({ label: `${p.name} (${formatRupiah(p.price)})`, value: String(p.id) })));

    const reply = await interaction.reply({ components: [new ActionRowBuilder().addComponents(selectMenu)], ephemeral: true, fetchReply: true });
    const selectInteraction = await reply.awaitMessageComponent({ time: 60000, filter: (i) => i.user.id === interaction.user.id }).catch(() => null);
    if (!selectInteraction) return;

    const product = db.getProductById(Number(selectInteraction.values[0]));
    if (!product) return selectInteraction.reply({ content: '❌ Produk tidak ditemukan.', ephemeral: true });

    const modal = new ModalBuilder().setCustomId(`modal_ubahharga_${product.id}`).setTitle(`Ubah Harga: ${product.name}`.slice(0, 45));
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('harga_baru').setLabel('Harga Baru (angka saja)').setStyle(TextInputStyle.Short).setRequired(true),
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('pesan_custom').setLabel('Pesan Chat Custom (broadcast)').setStyle(TextInputStyle.Paragraph).setRequired(true),
      ),
    );
    await selectInteraction.showModal(modal);

    const submitted = await selectInteraction.awaitModalSubmit({ time: 180000, filter: (i) => i.customId === `modal_ubahharga_${product.id}` }).catch(() => null);
    if (!submitted) return;

    const hargaBaru = parsePositiveInt(submitted.fields.getTextInputValue('harga_baru'));
    const pesanCustom = submitted.fields.getTextInputValue('pesan_custom').trim();
    if (hargaBaru === null) return submitted.reply({ content: '❌ Harga baru harus angka bulat positif.', ephemeral: true });

    const hargaLama = product.price;
    db.updateProductPrice(product.id, hargaBaru);
    await submitted.reply({ content: `✅ Harga **${product.name}** diubah dari ${formatRupiah(hargaLama)} menjadi ${formatRupiah(hargaBaru)}.`, ephemeral: true });

    const cfg = db.getGuildConfig(interaction.guildId);
    if (cfg?.info_channel_id) {
      const embed = new EmbedBuilder()
        .setColor(config.embed_color)
        .setTitle(`✏️ Update Harga: ${product.name}`)
        .setDescription(pesanCustom)
        .addFields(
          { name: 'Harga Lama', value: formatRupiah(hargaLama), inline: true },
          { name: 'Harga Baru', value: formatRupiah(hargaBaru), inline: true },
        )
        .setTimestamp();
      const guild = await client.guilds.fetch(interaction.guildId);
      const infoChannel = await guild.channels.fetch(cfg.info_channel_id).catch(() => null);
      if (infoChannel) await infoChannel.send({ embeds: [embed] }).catch(() => {});
    }
    return;
  }

  // ================== ADMIN PANEL: HAPUS PRODUK ==================
  if (id === 'admin_hapus_produk') {
    if (!(await requireAdmin(interaction))) return;
    const products = db.listProducts(interaction.guildId);
    if (products.length === 0) return interaction.reply({ content: '⚠️ Belum ada produk.', ephemeral: true });

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('select_hapus_produk')
      .setPlaceholder('Pilih produk yang mau dihapus')
      .addOptions(products.slice(0, 25).map((p) => ({ label: `${p.name} (stok: ${p.stock})`, value: String(p.id) })));

    const reply = await interaction.reply({ components: [new ActionRowBuilder().addComponents(selectMenu)], ephemeral: true, fetchReply: true });
    const selectInteraction = await reply.awaitMessageComponent({ time: 60000, filter: (i) => i.user.id === interaction.user.id }).catch(() => null);
    if (!selectInteraction) return;

    const product = db.getProductById(Number(selectInteraction.values[0]));
    if (!product) return selectInteraction.reply({ content: '❌ Produk tidak ditemukan.', ephemeral: true });

    const confirmRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('konfirmasi_hapus_ya').setLabel(`Ya, Hapus "${product.name}"`.slice(0, 80)).setStyle(ButtonStyle.Danger).setEmoji('🗑️'),
      new ButtonBuilder().setCustomId('konfirmasi_hapus_batal').setLabel('Batal').setStyle(ButtonStyle.Secondary).setEmoji('🚫'),
    );
    await selectInteraction.update({
      content: `⚠️ Produk **${product.name}** akan dihapus PERMANEN dari database (termasuk data akun yang tersimpan, jika ada). Yakin?`,
      components: [confirmRow],
    });

    const confirmInteraction = await reply.awaitMessageComponent({ time: 30000, filter: (i) => i.user.id === interaction.user.id }).catch(() => null);
    if (!confirmInteraction) return;

    if (confirmInteraction.customId === 'konfirmasi_hapus_batal') {
      return confirmInteraction.update({ content: '🚫 Penghapusan produk dibatalkan.', components: [] });
    }

    // Hapus pesan katalog produk (jika masih ada) supaya langsung hilang dari tampilan
    if (product.channel_id && product.message_id) {
      try {
        const guild = await client.guilds.fetch(interaction.guildId);
        const productChannel = await guild.channels.fetch(product.channel_id).catch(() => null);
        const productMsg = productChannel ? await productChannel.messages.fetch(product.message_id).catch(() => null) : null;
        if (productMsg) await productMsg.delete().catch(() => {});
      } catch (err) {
        // abaikan jika pesan/channel sudah tidak ada
      }
    }

    db.deleteProduct(product.id);
    await confirmInteraction.update({ content: `✅ Produk **${product.name}** berhasil dihapus permanen dari database & katalog.`, components: [] });
    return;
  }

  // ================== ADMIN PANEL: BUKA TOKO / TUTUP TOKO ==================
  if (id === 'store_open' || id === 'store_close') {
    if (!(await requireAdmin(interaction))) return;

    const cfg = db.getGuildConfig(interaction.guildId);
    if (!cfg) return interaction.reply({ content: '⚠️ Jalankan `/setup` terlebih dahulu.', ephemeral: true });

    const kondisi = id === 'store_open' ? 'OPEN' : 'CLOSE';
    const label = kondisi === 'OPEN' ? 'TOKO OPEN' : 'TOKO CLOSE';
    db.setStoreStatus(interaction.guildId, kondisi);

    await interaction.reply({ content: `✅ Status toko diubah menjadi **${label}**.`, ephemeral: true });

    // Update embed panel admin supaya status yang tertampil ikut berubah
    try {
      const oldEmbed = interaction.message.embeds[0];
      const newEmbed = EmbedBuilder.from(oldEmbed).setFields({ name: 'Status Toko Saat Ini', value: `**${label} ${kondisi === 'OPEN' ? '🟢' : '🔴'}**` });
      await interaction.message.edit({ embeds: [newEmbed] }).catch(() => {});
    } catch (err) {
      // abaikan jika gagal update tampilan panel, status di DB tetap berubah
    }

    if (cfg.info_channel_id) {
      const infoChannel = await interaction.guild.channels.fetch(cfg.info_channel_id).catch(() => null);
      if (infoChannel) {
        const embed = new EmbedBuilder()
          .setColor(kondisi === 'OPEN' ? config.embed_color_success : config.embed_color_danger)
          .setTitle(kondisi === 'OPEN' ? config.messages.toko_open_title : config.messages.toko_close_title)
          .setDescription(kondisi === 'OPEN' ? config.messages.toko_open_desc : config.messages.toko_close_desc)
          .setTimestamp();
        await infoChannel.send({ embeds: [embed] }).catch(() => {});
      }
    }
    return;
  }

  // ================== VOUCH (tombol di ticket & DM setelah pembelian sukses) ==================
  if (id.startsWith('vouch_')) {
    const orderId = Number(id.slice('vouch_'.length));
    const order = db.getOrderById(orderId);
    if (!order || order.status !== 'SUCCESS') {
      return interaction.reply({ content: '❌ Transaksi ini tidak valid untuk diberi vouch.', ephemeral: true });
    }
    if (db.hasVouch(orderId)) {
      return interaction.reply({ content: '⚠️ Kamu sudah memberikan vouch untuk transaksi ini. Terima kasih!', ephemeral: true });
    }

    const modal = new ModalBuilder().setCustomId(`modal_vouch_${orderId}`).setTitle('Berikan Vouch');
    modal.addComponents(
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('rating').setLabel('Rating (1-5)').setStyle(TextInputStyle.Short).setRequired(true)),
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('komentar').setLabel('Komentar Vouch').setStyle(TextInputStyle.Paragraph).setRequired(true)),
    );
    await interaction.showModal(modal);

    const submitted = await interaction.awaitModalSubmit({ time: 180000, filter: (i) => i.customId === `modal_vouch_${orderId}` }).catch(() => null);
    if (!submitted) return;

    const ratingRaw = submitted.fields.getTextInputValue('rating').trim();
    if (!/^[1-5]$/.test(ratingRaw)) {
      return submitted.reply({ content: '❌ Rating harus berupa angka 1 sampai 5.', ephemeral: true });
    }
    const rating = Number(ratingRaw);
    const komentar = submitted.fields.getTextInputValue('komentar').trim();

    if (db.hasVouch(orderId)) {
      return submitted.reply({ content: '⚠️ Kamu sudah memberikan vouch untuk transaksi ini. Terima kasih!', ephemeral: true });
    }
    db.addVouch({ guildId: order.guild_id, orderId: order.id, buyerId: order.buyer_id, rating, comment: komentar });

    const cfg = db.getGuildConfig(order.guild_id);
    const guild = await client.guilds.fetch(order.guild_id).catch(() => null);
    if (guild && cfg?.vouch_channel_id) {
      const vouchChannel = await guild.channels.fetch(cfg.vouch_channel_id).catch(() => null);
      if (vouchChannel) {
        const stars = '⭐'.repeat(rating) + '☆'.repeat(5 - rating);
        const vouchText =
          `## VOUCH\n` +
          `**Nominal**\n${formatRupiah(order.total_price)}\n` +
          `Dari <@${order.buyer_id}>\n` +
          `**Rating**\n${stars}\n` +
          `**Komentar**\n${komentar}`;
        const embed = new EmbedBuilder().setColor(config.embed_color_vouch).setDescription(vouchText).setTimestamp();
        await vouchChannel.send({ embeds: [embed] }).catch(() => {});
      }
    }

    await submitted.reply({ content: '✅ Terima kasih atas vouch-nya! Channel order ini akan dihapus.', ephemeral: true });

    // Vouch sudah diberikan -> channel order tugasnya selesai, hapus sekarang (baru boleh dihapus setelah vouch)
    if (guild) {
      const ticketChannel = await guild.channels.fetch(order.channel_id).catch(() => null);
      if (ticketChannel) {
        await ticketChannel.send('✅ Terima kasih sudah memberi vouch! Channel ini akan dihapus.').catch(() => {});
        setTimeout(() => ticketChannel.delete().catch(() => {}), 5000);
      }
    }
    return;
  }

  // ================== KONFIRMASI PESANAN: BERHASIL / DIBATALKAN (khusus Owner/Admin) ==================
  if (id.startsWith('confirm_success_')) {
    if (!(await requireAdmin(interaction))) return;
    const orderId = Number(id.slice('confirm_success_'.length));
    return confirmSukses(interaction, orderId);
  }
  if (id.startsWith('confirm_cancel_')) {
    if (!(await requireAdmin(interaction))) return;
    const orderId = Number(id.slice('confirm_cancel_'.length));
    return batalkanOrder(interaction, orderId);
  }
}

module.exports = { handle };
