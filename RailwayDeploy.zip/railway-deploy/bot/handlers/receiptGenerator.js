// handlers/receiptGenerator.js
// Menghasilkan gambar NOTA TRANSAKSI (PNG) yang dikirim via DM ke pembeli.
// Format teks ASCII monospace (mirip struk polos), dengan nama toko/server disisipkan
// di bagian header.
//
// Catatan: memakai @napi-rs/canvas (bukan library "canvas" klasik) karena API-nya
// nyaris identik tapi sudah tersedia prebuilt binary -> jauh lebih ringan & stabil
// dipasang di Termux Android dibanding node-canvas yang butuh kompilasi native berat.

const fs = require('fs');
const { createCanvas, GlobalFonts } = require('@napi-rs/canvas');
const { formatRupiah } = require('../utils/helpers');

// Coba daftarkan font monospace dari lokasi umum di Android/Linux supaya rendering
// teks tetap rapi & sejajar (grid ASCII) walau Termux tidak menginstal font apapun
// secara default. Jika tidak ada yang ketemu, canvas tetap jalan pakai fallback "monospace".
let monoFontFamily = 'monospace';
const fontCandidates = [
  { path: '/system/fonts/RobotoMono-Regular.ttf', family: 'ReceiptMono' },
  { path: '/system/fonts/DroidSansMono.ttf', family: 'ReceiptMono' },
  { path: '/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf', family: 'ReceiptMono' },
  { path: '/data/data/com.termux/files/usr/share/fonts/TTF/DejaVuSansMono.ttf', family: 'ReceiptMono' },
];
for (const candidate of fontCandidates) {
  try {
    if (fs.existsSync(candidate.path)) {
      GlobalFonts.registerFromPath(candidate.path, candidate.family);
      monoFontFamily = candidate.family;
      break;
    }
  } catch (err) {
    // abaikan, lanjut coba kandidat berikutnya
  }
}

function monoFont(size) {
  return `${size}px ${monoFontFamily}, monospace`;
}

const LINE_WIDTH = 40; // lebar baris nota dalam jumlah karakter
const LABEL_WIDTH = 13; // lebar kolom label supaya semua ":" sejajar

function centerText(text, width = LINE_WIDTH) {
  if (text.length >= width) return text.slice(0, width);
  const totalPad = width - text.length;
  const left = Math.floor(totalPad / 2);
  const right = totalPad - left;
  return ' '.repeat(left) + text + ' '.repeat(right);
}

function labelRow(label, value, width = LINE_WIDTH) {
  let line = `${label.padEnd(LABEL_WIDTH, ' ')}: ${value}`;
  if (line.length > width) line = line.slice(0, width - 1) + '…';
  return line;
}

function generateReceiptImage({ orderId, usn, orderName, jumlah, hargaTotal, hargaSatuan, tanggalWIB, serverName }) {
  const produkDisplay = orderName.length > 24 ? orderName.slice(0, 24) + '…' : orderName;
  const serverDisplay = (serverName || 'Toko').length > LINE_WIDTH ? serverName.slice(0, LINE_WIDTH) : (serverName || 'Toko');

  // ---- Format persis sesuai permintaan (nama toko disisipkan di header) ----
  const lines = [
    '='.repeat(LINE_WIDTH),
    centerText('NOTA TRANSAKSI'),
    centerText(serverDisplay),
    '='.repeat(LINE_WIDTH),
    labelRow('Status', 'BERHASIL'),
    labelRow('ID Transaksi', orderId),
    labelRow('Waktu', tanggalWIB),
    '-'.repeat(LINE_WIDTH),
    labelRow('Pelanggan', usn),
    labelRow('Produk', produkDisplay),
    labelRow('Harga', formatRupiah(hargaSatuan)),
    labelRow('Jumlah', String(jumlah)),
    '-'.repeat(LINE_WIDTH),
    labelRow('TOTAL TAGIHAN', formatRupiah(hargaTotal)),
    '-'.repeat(LINE_WIDTH),
    '='.repeat(LINE_WIDTH),
    centerText('Terima Kasih Telah Bertransaksi'),
    '='.repeat(LINE_WIDTH),
  ];

  // Ukur lebar 1 karakter monospace secara dinamis supaya grid ASCII tetap presisi
  // di font apapun yang berhasil dimuat pada perangkat.
  const fontSize = 22;
  const probeCanvas = createCanvas(10, 10);
  const probeCtx = probeCanvas.getContext('2d');
  probeCtx.font = monoFont(fontSize);
  const charWidth = probeCtx.measureText('0').width || fontSize * 0.6;

  const paddingX = 34;
  const paddingY = 34;
  const lineHeight = Math.round(fontSize * 1.45);

  const width = Math.ceil(charWidth * LINE_WIDTH) + paddingX * 2;
  const height = lineHeight * lines.length + paddingY * 2;

  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  // Background putih/krem ala kertas nota
  ctx.fillStyle = '#fdfbf5';
  ctx.fillRect(0, 0, width, height);

  ctx.fillStyle = '#111111';
  ctx.font = monoFont(fontSize);
  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';

  lines.forEach((line, i) => {
    ctx.fillText(line, paddingX, paddingY + i * lineHeight);
  });

  return canvas.toBuffer('image/png');
}

module.exports = { generateReceiptImage };
