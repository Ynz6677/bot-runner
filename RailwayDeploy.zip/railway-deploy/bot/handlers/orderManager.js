// handlers/orderManager.js
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits, StringSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const db = require('../database');
const config = require('../config.json');
const { formatRupiah, generateTransactionId, toChannelSafeName, parsePositiveInt, parseRoleIds } = require('../utils/helpers');

function buttonFromConfig(key, customId) {
  const b = config.buttons[key];
  const btn = new ButtonBuilder().setCustomId(customId).setLabel(b.label).setStyle(ButtonStyle[b.style] || ButtonStyle.Secondary);
  if (b.emoji) btn.setEmoji(b.emoji);
  return btn;
}

function statusLogText(orderId, usn, orderName, statusKey) {
  const status = config.status_labels[statusKey] || statusKey;
  return (
    '```\n' +
    `ID     : ${orderId}\n` +
    `USN    : ${usn}\n` +
    `ORDER  : ${orderName}\n` +
    `STATUS : ${status}\n` +
    '```'
  );
}

// Dipanggil dari tombol Order (dipasang lewat /order place) atau tombol Order lama yang tersimpan.
// options: { type, categoryId }
//   - type       -> opsional, hanya dipakai untuk kompatibilitas lama (sekarang selalu kosong -> tampilkan semua tipe)
//   - categoryId -> kategori channel (folder Discord) tempat channel order baru akan dibuat
// Alur: pilih channel order (kategori produk) -> pilih produk di channel itu -> Modal (USN, Jumlah).
async function startOrderFlow(interaction, options = {}) {
  const { type, categoryId } = options;

  const cfg = db.getGuildConfig(interaction.guildId);
  if (!cfg || cfg.store_status !== 'OPEN') {
    return interaction.reply({ content: config.messages.toko_closed_error, ephemeral: true });
  }

  const categories = db.getAvailableCategories(interaction.guildId, type);
  if (categories.length === 0) {
    return interaction.reply({ content: '⚠️ Belum ada barang yang tersedia (stok kosong) saat ini.', ephemeral: true });
  }

  const channelSelect = new StringSelectMenuBuilder()
    .setCustomId('select_order_channel')
    .setPlaceholder('Pilih channel order')
    .addOptions(
      categories.slice(0, 25).map((c) => ({
        label: (c.category || 'Tanpa Kategori').slice(0, 100),
        value: c.channel_id,
      })),
    );

  const reply = await interaction.reply({
    content: '📂 Silakan pilih channel order barang yang ingin kamu beli:',
    components: [new ActionRowBuilder().addComponents(channelSelect)],
    ephemeral: true,
    fetchReply: true,
  });

  const channelPicked = await reply.awaitMessageComponent({ time: 60000, filter: (i) => i.user.id === interaction.user.id }).catch(() => null);
  if (!channelPicked) return;

  const products = db.listProductsInChannel(interaction.guildId, channelPicked.values[0], type);
  if (products.length === 0) {
    return channelPicked.update({ content: '⚠️ Tidak ada barang tersedia di channel order ini.', components: [] });
  }

  const productSelect = new StringSelectMenuBuilder()
    .setCustomId('select_order_product')
    .setPlaceholder('Pilih barang yang ingin dipesan')
    .addOptions(
      products.slice(0, 25).map((p) => ({
        label: p.name.slice(0, 100),
        description: `${formatRupiah(p.price)} | Stok: ${p.stock}`.slice(0, 100),
        value: String(p.id),
      })),
    );

  await channelPicked.update({
    content: '🛒 Silakan pilih barang yang ingin kamu pesan:',
    components: [new ActionRowBuilder().addComponents(productSelect)],
  });

  const productPicked = await reply.awaitMessageComponent({ time: 60000, filter: (i) => i.user.id === interaction.user.id }).catch(() => null);
  if (!productPicked) return;

  const product = db.getProductById(Number(productPicked.values[0]));
  if (!product) return productPicked.reply({ content: '❌ Produk tidak ditemukan / sudah dihapus.', ephemeral: true });

  const modal = new ModalBuilder().setCustomId(`modal_order_${product.id}`).setTitle(`Order: ${product.name}`.slice(0, 45));
  modal.addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('usn').setLabel('USN / Nama Kamu').setStyle(TextInputStyle.Short).setRequired(true)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('jumlah').setLabel('Jumlah Pembelian').setStyle(TextInputStyle.Short).setRequired(true)),
  );
  await productPicked.showModal(modal);

  const submitted = await productPicked.awaitModalSubmit({ time: 120000, filter: (i) => i.customId === `modal_order_${product.id}` }).catch(() => null);
  if (!submitted) return;

  const usn = submitted.fields.getTextInputValue('usn').trim();
  const qty = parsePositiveInt(submitted.fields.getTextInputValue('jumlah'));

  if (!usn) return submitted.reply({ content: '❌ USN/Nama tidak boleh kosong.', ephemeral: true });
  if (qty === null) {
    return submitted.reply({ content: '❌ Jumlah pembelian wajib berupa angka bulat positif (bukan huruf/minus/desimal).', ephemeral: true });
  }

  const freshProduct = db.getProductById(product.id); // ambil ulang stok terbaru
  await createOrderTicket(submitted, { usn, product: freshProduct, qty, parentCategoryId: categoryId });
}

// Dipanggil setelah pembeli memilih produk & submit Modal Order (usn, jumlah).
// interaction di sini adalah ModalSubmitInteraction.
// parentCategoryId: kategori channel (folder Discord) tempat channel order baru dibuat (opsional).
async function createOrderTicket(interaction, { usn, product, qty, parentCategoryId }) {
  const guild = interaction.guild;
  const cfg = db.getGuildConfig(guild.id);

  if (!cfg || !cfg.admin_role_id || !cfg.admin_status_channel_id) {
    return interaction.reply({ content: '⚠️ Toko belum dikonfigurasi lengkap. Admin harap jalankan `/setup` terlebih dahulu.', ephemeral: true });
  }

  if (cfg.store_status !== 'OPEN') {
    return interaction.reply({ content: config.messages.toko_closed_error, ephemeral: true });
  }

  // Anti-spam: maksimal 1 order aktif (PENDING) per pembeli
  const activeOrder = db.getActiveOrderByBuyer(guild.id, interaction.user.id);
  if (activeOrder) {
    return interaction.reply({
      content: `⚠️ Kamu masih memiliki order aktif di <#${activeOrder.channel_id}>. Selesaikan/tunggu order tersebut terlebih dahulu.`,
      ephemeral: true,
    });
  }

  if (product.stock < qty) {
    return interaction.reply({ content: `❌ Stok **${product.name}** tidak mencukupi (sisa ${product.stock}).`, ephemeral: true });
  }

  await interaction.deferReply({ ephemeral: true });

  const adminRoleIds = parseRoleIds(cfg.admin_role_id);

  // Reservasi stok dulu -> dikembalikan otomatis jika dibatalkan/expired
  db.decrementStock(product.id, qty);

  // Jika stok jadi habis (0), otomatis hapus pesan katalognya dari channel supaya tidak bisa dipesan lagi.
  // channel_id tetap disimpan di DB supaya bisa dipublikasikan ulang otomatis saat direstok nanti.
  const productAfterDecrement = db.getProductById(product.id);
  if (productAfterDecrement.stock <= 0 && productAfterDecrement.channel_id && productAfterDecrement.message_id) {
    try {
      const prodChannel = await guild.channels.fetch(productAfterDecrement.channel_id).catch(() => null);
      const prodMsg = prodChannel ? await prodChannel.messages.fetch(productAfterDecrement.message_id).catch(() => null) : null;
      if (prodMsg) await prodMsg.delete().catch(() => {});
      db.clearProductMessageId(productAfterDecrement.id);
    } catch (err) {
      console.error('[orderManager] Gagal menyembunyikan katalog produk stok habis:', err.message);
    }
  }

  const totalPrice = product.price * qty;
  const orderId = generateTransactionId(); // ID Transaksi, contoh: WX583920

  // Nama channel order sekuensial: order-001, order-002, dst (kontinu, tidak pernah reset)
  const orderNumber = db.getNextOrderNumber(guild.id);
  const channelName = `order-${String(orderNumber).padStart(3, '0')}`;

  let orderChannel;
  try {
    orderChannel = await guild.channels.create({
      name: toChannelSafeName(channelName),
      type: ChannelType.GuildText,
      parent: parentCategoryId || undefined,
      permissionOverwrites: [
        { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
        { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.AttachFiles, PermissionFlagsBits.ReadMessageHistory] },
        ...adminRoleIds.map((roleId) => ({ id: roleId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.AttachFiles, PermissionFlagsBits.ReadMessageHistory] })),
      ],
    });
  } catch (err) {
    db.restoreStock(product.id, qty); // gagal buat channel -> kembalikan stok
    return interaction.editReply({ content: '❌ Gagal membuat channel order. Cek permission bot (Manage Channels) & pastikan kategori channel masih ada.' });
  }

  const orderDbId = db.createOrder({
    guildId: guild.id,
    orderCode: orderId,
    channelId: orderChannel.id,
    buyerId: interaction.user.id,
    buyerUsername: interaction.user.username,
    usn,
    productId: product.id,
    productName: product.name,
    productType: product.type,
    quantity: qty,
    totalPrice,
  });

  // 1) Tampilkan QRIS otomatis + info metode pembayaran tambahan
  const bayarEmbed = new EmbedBuilder()
    .setColor(config.embed_color)
    .setTitle('💳 Pembayaran via QRIS')
    .setDescription(cfg.payment_info || 'Silakan scan QRIS di bawah ini untuk melakukan pembayaran.')
    .setFooter({ text: `ID Transaksi: ${orderId} | Batas waktu ${config.timeout_order_minutes} menit` });
  if (cfg.qris_image_url) bayarEmbed.setImage(cfg.qris_image_url);

  await orderChannel.send({
    content: `<@${interaction.user.id}> Terima kasih sudah order!`,
    embeds: [bayarEmbed],
  });

  await orderChannel.send(
    `${config.messages.bukti_transaksi_warning}\nSilakan upload foto/screenshot bukti transfer kamu langsung di channel ini.`,
  );

  // Rincian pesanan singkat untuk pembeli (di channel order, TANPA tombol konfirmasi apapun)
  const detailEmbed = new EmbedBuilder()
    .setColor(config.embed_color)
    .setTitle('🧾 Rincian Pesanan')
    .addFields(
      { name: 'ID', value: `\`${orderId}\``, inline: true },
      { name: 'USN', value: `**${usn}**`, inline: true },
      { name: 'Nama Produk', value: `**${product.name}**`, inline: false },
      { name: 'Harga', value: `**${formatRupiah(product.price)}**`, inline: true },
      { name: 'Jumlah', value: `**${qty}**`, inline: true },
      { name: 'Total', value: `**${formatRupiah(totalPrice)}**`, inline: true },
    );
  await orderChannel.send({ embeds: [detailEmbed] });

  // 2) Kirim log status + tombol Berhasil/Dibatalkan ke CHANNEL ADMIN TERPISAH (bukan channel order pembeli)
  const statusChannel = await guild.channels.fetch(cfg.admin_status_channel_id).catch(() => null);
  if (statusChannel) {
    const row = new ActionRowBuilder().addComponents(
      buttonFromConfig('berhasil', `confirm_success_${orderDbId}`),
      buttonFromConfig('dibatalkan', `confirm_cancel_${orderDbId}`),
    );
    const statusMsg = await statusChannel.send({
      content: `${adminRoleIds.map((roleId) => `<@&${roleId}>`).join(' ')} ${statusLogText(orderId, usn, product.name, 'MENUNGGU')}\nChannel: <#${orderChannel.id}>`,
      components: [row],
    });
    db.setOrderStatusMessage(orderDbId, statusMsg.id);
  }

  await interaction.editReply({ content: `✅ Order berhasil dibuat! Silakan lanjut ke <#${orderChannel.id}>` });
}

// Dipanggil berkala untuk membatalkan otomatis order yang timeout (belum ada bukti transaksi)
// Membatalkan/mereset paksa sebuah order yang masih PENDING: kembalikan stok, hapus channel order,
// update log status di channel admin. Dipakai oleh pengecekan timeout otomatis (expireOldOrders)
// MAUPUN oleh command /reset (admin menghilangkan order aktif yang macet secara manual).
// Tidak ada DM apapun ke pembeli saat ini terjadi.
async function voidPendingOrder(client, order, note) {
  db.updateOrderStatus(order.id, 'EXPIRED');
  db.restoreStock(order.product_id, order.quantity); // stok yang sempat terpotong dikembalikan

  try {
    const guild = await client.guilds.fetch(order.guild_id);

    const channel = await guild.channels.fetch(order.channel_id).catch(() => null);
    if (channel) {
      await channel.send(`⏰ ${note || 'Order ini dibatalkan.'} Channel akan dihapus.`).catch(() => {});
      setTimeout(() => channel.delete().catch(() => {}), 3000);
    }

    // Update juga log status di channel admin supaya tidak menggantung "MENUNGGU KONFIRMASI"
    const cfg = db.getGuildConfig(order.guild_id);
    if (cfg?.admin_status_channel_id && order.status_message_id) {
      const statusChannel = await guild.channels.fetch(cfg.admin_status_channel_id).catch(() => null);
      const statusMsg = statusChannel ? await statusChannel.messages.fetch(order.status_message_id).catch(() => null) : null;
      if (statusMsg) {
        await statusMsg.edit({ content: statusLogText(order.order_code, order.usn, order.product_name, 'DIBATALKAN') + `\n_(${note || 'direset'})_`, components: [] }).catch(() => {});
      }
    }
  } catch (err) {
    console.error('[orderManager] Gagal void order:', err.message);
  }
}

async function expireOldOrders(client) {
  const timeoutMs = config.timeout_order_minutes * 60 * 1000;
  const expired = db.getExpiredPendingOrders(timeoutMs);

  for (const order of expired) {
    await voidPendingOrder(client, order, 'hangus otomatis, tidak ada bukti transaksi dalam batas waktu');
  }
}

module.exports = { createOrderTicket, startOrderFlow, expireOldOrders, voidPendingOrder, buttonFromConfig, statusLogText };
