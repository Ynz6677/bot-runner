// utils/permissions.js
const { PermissionFlagsBits } = require('discord.js');
const db = require('../database');
const { parseRoleIds } = require('./helpers');

function isAdmin(interaction) {
  const member = interaction.member;
  if (!member) return false;
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;

  const cfg = db.getGuildConfig(interaction.guildId);
  if (cfg && cfg.admin_role_id) {
    const adminRoleIds = parseRoleIds(cfg.admin_role_id);
    if (adminRoleIds.some((roleId) => member.roles.cache.has(roleId))) return true;
  }
  return false;
}

async function requireAdmin(interaction) {
  if (!isAdmin(interaction)) {
    await interaction.reply({
      content: '❌ Kamu tidak memiliki izin untuk menggunakan perintah/tombol ini.',
      ephemeral: true,
    });
    return false;
  }
  return true;
}

module.exports = { isAdmin, requireAdmin };
